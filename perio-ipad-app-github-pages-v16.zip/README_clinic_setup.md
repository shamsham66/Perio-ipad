# 歯周組織検査入力アプリ 医院設置メモ

このフォルダ内のファイル一式を、医院で固定URLとして開ける場所に置くと利用できます。

## 中身

- `index.html`: アプリ本体
- `app.js`: 入力動作
- `styles.css`: 画面デザイン
- `manifest.webmanifest`, `sw.js`, `icon.svg`: iPadのホーム画面追加とキャッシュ用

## 設置方法

### 1. WebサーバーやNASに置く場合

このフォルダ内のファイルを同じ場所にアップロードしてください。

例:

```text
https://clinic-example.jp/perio/
```

上のようなURLで `index.html` が開ければ使えます。

### 2. GitHub Pagesに置く場合

このフォルダの中身をGitHubリポジトリにアップロードし、GitHub Pagesを有効にします。

例:

```text
https://ユーザー名.github.io/perio-ipad-app/
```

### 3. iPadで使う場合

1. Safariで固定URLを開く
2. 共有ボタンを押す
3. 「ホーム画面に追加」を選ぶ
4. ホーム画面のアイコンから起動する

## 注意

- `127.0.0.1` や `localhost` のURLは確認用です。医院内の別端末やiPadからは固定利用できません。
- 固定URLとして使うには、医院のWebサーバー、NAS、常時起動PC、GitHub Pagesなどの設置先が必要です。
- この版では、患者データをアプリ内に永続保存しません。入力後はスクリーンショットを撮り、電子カルテへ貼り付ける運用を想定しています。
