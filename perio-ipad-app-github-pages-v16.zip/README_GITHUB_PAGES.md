# GitHub Pagesで固定URL化する手順

このフォルダの中身をGitHub Pagesに置くと、医院のiPadから固定URLで開けます。

## 1. GitHubアカウントを作る

https://github.com/ にアクセスして、無料アカウントを作成します。

## 2. 新しいリポジトリを作る

1. GitHub右上の `+` から `New repository`
2. Repository name: `perio-ipad-app`
3. Publicを選択
4. `Create repository`

## 3. ファイルをアップロードする

このZIPの中身を展開し、以下のファイルをリポジトリ直下にアップロードします。

- `index.html`
- `styles.css`
- `app.js`
- `manifest.webmanifest`
- `sw.js`
- `icon.svg`
- `.nojekyll`

## 4. GitHub Pagesを有効にする

1. リポジトリの `Settings`
2. 左メニューの `Pages`
3. `Build and deployment` の `Source` を `Deploy from a branch`
4. Branchを `main`、Folderを `/root`
5. `Save`

数分待つと、以下のようなURLが発行されます。

```text
https://ユーザー名.github.io/perio-ipad-app/
```

## 5. iPadでアプリのように使う

1. iPadのSafariで発行されたURLを開く
2. 共有ボタンを押す
3. `ホーム画面に追加`
4. ホーム画面のアイコンから起動

## データについて

この版では、患者データをアプリ内に永続保存しません。入力後はスクリーンショットを撮り、電子カルテへ貼り付ける運用を想定しています。
